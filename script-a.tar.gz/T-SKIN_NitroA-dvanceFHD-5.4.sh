
#!/bin/sh
#

wget https://raw.githubusercontent.com/tarekzoka/NitroAdvanceFHD/main/tarek1.sh -O - | /bin/sh