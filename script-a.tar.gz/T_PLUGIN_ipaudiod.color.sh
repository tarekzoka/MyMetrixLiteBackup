opkg remove enigma2-lamedb5 wait
sleep 2;

opkg install --force-overwrite https://drive.google.com/uc?id=1fw3UA5HS-MVf5E__X11ycXD4-itDxhaX&export=download
wait
sleep 2;
exit 0


