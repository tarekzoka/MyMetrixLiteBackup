opkg install --force-overwrite  https://drive.google.com/uc?id=1NEltK-3G3yZM9zHNa76J-Lm8L1gyFcgw&export=download
wait
sleep 2;
exit 0










