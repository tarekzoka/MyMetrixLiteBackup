opkg remove --force-depends enigma2-plugin-cams-tunisia-sat-active-code
wait
sleep 2;
exit 0











