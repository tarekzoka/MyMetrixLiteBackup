wget -q "--no-check-certificate" http://ipkinstall.ath.cx/ipk-install/DreamSatPanel/DreamSat-py-3.10.sh -O - | /bin/sh

