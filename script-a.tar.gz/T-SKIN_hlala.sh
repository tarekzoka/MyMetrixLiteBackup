

#!/bin/sh
#

wget https://raw.githubusercontent.com/tarekzoka/plugins/main/installers.sh -O - | /bin/sh  