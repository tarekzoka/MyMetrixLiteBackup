wait
opkg install --force-overwrite  
wget https://github.com/tarekzoka/plugins/blob/main/feeds-finder_20201016-V1.6-momi133-OE2_all.ipk?raw=true
wait
sleep 2;
exit 0














