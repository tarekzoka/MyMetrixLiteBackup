opkg install --force-overwrite https://github.com/tarekzoka/oscam-nacam/blob/main/enigma2-plugin-softcams-ncam_V12.5-r1_all.ipk?raw=true&authkey=ANtOCElaB-_APaQ
wait
sleep 2;
exit 0














