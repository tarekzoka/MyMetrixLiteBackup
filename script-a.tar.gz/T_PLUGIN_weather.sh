
#!/bin/sh
#

wget https://raw.githubusercontent.com/tarekzoka/DM/main/tarek.sh -O - | /bin/sh