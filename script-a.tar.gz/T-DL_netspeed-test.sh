#!/bin/sh
echo "Uninstall"
sleep 1
echo "odinstalace pluginu netspeedtest"
opkg remove enigma2-plugin-extensions-netspeedtest
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/NetSpeedTest/
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
echo "OK"
exit

