opkg remove --force-depends enigma2-softcams-oscam-all-images
wait
sleep 2;
exit 0



