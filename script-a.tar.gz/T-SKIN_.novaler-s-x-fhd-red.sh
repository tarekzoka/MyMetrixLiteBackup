echo
opkg install --force-overwrite  "https://drive.google.com/uc?id=190JD5kf9FB1m6BeXbMEfiqsyy5KSrl6F&export=download"
wait
sleep 2;
exit 0



