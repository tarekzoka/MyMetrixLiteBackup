opkg remove enigma2-softcams-cccam-all-images
wait
sleep 2;
exit 0


