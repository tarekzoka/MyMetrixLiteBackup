wget -q "--no-check-certificate" http://ipkinstall.ath.cx/ipk-install/E2IPLAYER+TSIPLAYER/installer.sh -O - | /bin/sh
wait
sleep 2;
exit 0
