
#!/bin/sh
#

wget http://tunisia-dreambox.info/TSplugins/TSiplayer/installer.sh -O - | /bin/sh