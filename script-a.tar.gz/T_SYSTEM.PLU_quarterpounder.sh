opkg install --force-overwrite  https://oottppxx.github.io/enigma2/latest/quarterpounder-latest.ipk
wait
sleep 2;
exit 0
