opkg remove enigma2-plugin-softcams-ncam-mips
wait
sleep 2;
opkg install --force-overwrite https://drive.google.com/uc?id=1Gy0zTQzmS7kHSCQj7FGRlfRdzNMVhmaN&export=download
wait
sleep 2;
exit 0


























