opkg remove enigma2-softcams-cccam-all-images
wait
sleep 2;
opkg install --force-overwrite  https://drive.google.com/uc?id=1PZPAFCUbAWV5-_C-ZCLRV1c2oENoeIV0&export=download
wait
sleep 2;
exit 0


